class ImageDecodingPlugin {
	constructor (API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addModifiers () {
		const scopes = this.config.scope.split('|');
		const isPostScope = scopes.includes('post');
		const isPageScope = scopes.includes('page');
		const isBothScope = scopes.includes('both');

		if (isPostScope || isBothScope) {
			this.API.addModifier('postText', this.addDecodingAttribute.bind(this), 1, this);
		}
		if (isPageScope || isBothScope) {
			this.API.addModifier('pageText', this.addDecodingAttribute.bind(this), 1, this);
		}
	}

	addDecodingAttribute (rendererInstance, text) {
		text = text.replace(/\<img /gmi, '<img decoding="' + this.config.decodingMode + '" ');
		return text;
	}
}

module.exports = ImageDecodingPlugin;