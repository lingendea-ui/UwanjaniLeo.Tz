class simpleLightboxGallery {
	constructor(API, name, config) {
		 this.API = API;
		 this.name = name;
		 this.config = config;

		 this.API.addModifier('htmlOutput', this.modifyHTML.bind(this), 1, this);
		 this.API.addInsertion('customHeadCode', this.addStyles.bind(this), 1, this);
		 this.API.addInsertion('customFooterCode', this.addScripts.bind(this), 1, this);
	}

	// Modify the HTML output to add unique data attributes for the lightbox
	modifyHTML(rendererInstance, htmlCode) {
		 const assignUniqueGalleryGroups = !!this.config.uniqueGalleryGroups;

		 // Helper function to escape special HTML characters
		 function escapeHTML(str) {
			  return str
					.replace(/&/g, '&amp;')
					.replace(/</g, '&lt;')
					.replace(/>/g, '&gt;')
					.replace(/"/g, '&quot;')
					.replace(/'/g, '&#39;');
		 }

		 const galleryRegex = /<div class="gallery.*?>[\s\S]*?<\/div>/gis;
		 let galleryIndex = 0;

		 return htmlCode.replace(galleryRegex, galleryMarkup => {
			  galleryIndex++;
			  const groupId = assignUniqueGalleryGroups ? `galleryGroup-${galleryIndex}` : 'galleryGroup';

			  return galleryMarkup.replace(/<figure class="gallery__item">[\s\S]*?<\/figure>/gis, figureMarkup => {
					const figCaptionMatch = /<figcaption(?:\s+[^>]*)?>(.*?)<\/figcaption>/i.exec(figureMarkup);
					const title = figCaptionMatch ? figCaptionMatch[1].trim() : '';

					return figureMarkup.replace(/<a (.*?)>/, (match, attributes) => {
						 let modifiedAttributes = attributes;

						 if (!/data-gall="[^"]*"/.test(modifiedAttributes)) {
							  modifiedAttributes += ` data-gall="${groupId}"`;
						 }

						 if (title) {
							  const sanitizedTitle = escapeHTML(title); // Escape the title
							  if (!/data-title="[^"]*"/.test(modifiedAttributes)) {
									modifiedAttributes += ` data-title="${sanitizedTitle}"`;
							  }
						 }

						 return `<a ${modifiedAttributes}>`;
					});
			  });
		 });
	}

	// Add lightbox styles to the page
	addStyles(rendererInstance, context) {
		 if (!context.post?.hasGallery && !context.page?.hasGallery) return '';

		 return `
			  <link rel="stylesheet" href="${rendererInstance.siteConfig.domain}/media/plugins/simpleLightboxGallery/venobox.min.css" />
		 `;
	}

	// Add lightbox initialization script to the page
	addScripts(rendererInstance, context) {
		 if (!context.post?.hasGallery && !context.page?.hasGallery) return '';

		 const config = this.config;

		 const safeValue = (value, defaultValue) => value != null ? value : defaultValue;

		 const options = {
			  selector: '.gallery__item a',
			  titleattr: 'data-title',
			  bgcolor: safeValue(config.bgcolor, 'rgba(38, 40, 44, 1)'),
			  fitView: !!safeValue(config.fitView, false),
			  infinigall: !!safeValue(config.infinigall, false),
			  maxWidth: safeValue(config.maxWidth, '100%'),
			  navigation: !!safeValue(config.navigation, false),
			  navKeyboard: !!safeValue(config.navKeyboard, false),
			  navTouch: !!safeValue(config.navTouch, false),
			  navSpeed: parseInt(safeValue(config.navSpeed, 300), 10),
			  numeration: !!safeValue(config.numeration, false),
			  overlayClose: !!safeValue(config.overlayClose, true),
			  overlayColor: safeValue(config.overlayColor, 'rgba(0,0,0,0.8)'),
			  share: !!safeValue(config.share, false),
			  shareStyle: safeValue(config.shareStyle, 'bar'),
			  spinColor: safeValue(config.toolsColor, '#d2d2d2'),
			  spinner: safeValue(config.spinner, 'bounce'),
			  titlePosition: safeValue(config.titlePosition, 'top'),
			  titleStyle: safeValue(config.titleStyle, 'block'),
			  toolsBackground: safeValue(config.toolsBackground, '#1C1C1C'),
			  toolsColor: safeValue(config.toolsColor, '#d2d2d2'),
			  initialScale: parseFloat(safeValue(config.initialScale, 0.9)),
			  transitionSpeed: parseInt(safeValue(config.transitionSpeed, 200), 10)
		 };

		 // Generate options as a string for the plugin initialization
		 const optionsLines = Object.entries(options)
			  .map(([key, value]) => {
					if (typeof value === 'string') {
						 return `${key}: '${value}'`;
					} else {
						 return `${key}: ${value}`;
					}
			  })
			  .join(',\n');

		 return `
			  <script defer src="${rendererInstance.siteConfig.domain}/media/plugins/simpleLightboxGallery/venobox.min.js"></script>
			  <script type="text/javascript">
					document.addEventListener("DOMContentLoaded", () => {
						 try {
							  if (typeof VenoBox !== 'undefined') {
									new VenoBox({
										 ${optionsLines}
									});
							  } else {
									console.error("VenoBox script not loaded.");
							  }
						 } catch (error) {
							  console.error("Failed to initialize VenoBox:", error);
						 }
					});
			  </script>
		 `;
	}
}

module.exports = simpleLightboxGallery;
