class PlausibleAnalyticsIntegrationPlugin {
	constructor(API, name, config) {
	  this.API = API;
	  this.name = name;
	  this.config = config;
	}
 
	addInsertions() {
	  this.API.addInsertion('publiiHead', this.addHeadCode, 1, this);
	}
 
	addHeadCode(rendererInstance) {
	  let scriptToLoad = '';
	  let cookieBannerGroup = 'text/javascript';
	
	  if (this.config.cookieBannerIntegration) {
		 cookieBannerGroup = 'gdpr-blocker/' + this.config.cookieBannerGroup.trim();
	  }
	
	  if (!rendererInstance.previewMode || this.config.previewMode) {
		 let scriptURL = this.config.scriptURL;
	
		 if (!scriptURL || scriptURL.trim() === '') {
			scriptURL = 'https://plausible.io/js/plausible.js';
		 }
	
		 scriptToLoad = `
			<script 
			  defer 
			  type="${cookieBannerGroup}"
			  data-domain="${this.config.domain}" 
			  src="${scriptURL}"></script>
			<script>window.plausible = window.plausible || function() { (window.plausible.q = window.plausible.q || []).push(arguments) }</script>
		 `;
	
		 // Dodanie warunkowego skryptu dla 404, jeżeli jest to strona 404
		 if (rendererInstance.globalContext.context.includes('404')) {
			scriptToLoad += `<script>document.addEventListener('DOMContentLoaded', function () { plausible('404', { props: { path: document.location.pathname } }); });</script>`;
		 }
	  }
	
	  return scriptToLoad;
	}
 }
 
 module.exports = PlausibleAnalyticsIntegrationPlugin;
 