class UmamiAnalyticsIntegrationPlugin {
	constructor (API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addInsertions () {
		this.API.addInsertion('publiiHead', this.addHeadCode, 1, this);
	}

	addHeadCode (rendererInstance) {
		let scriptToLoad = '';
		let cookieBannerGroup = 'text/javascript';
		let dataHostURL = `data-host-url="${this.config.dataHostURL}"`;
		let dataDomains = `data-host-url="${this.config.dataDomains}"`;

		if (!this.config.dataHostURL) {
			dataHostURL = this.config.dataHostURL;
		}

		if (!this.config.dataDomains) {
			dataDomains = this.config.dataDomains;
		}

		if (this.config.cookieBannerIntegration) {
			cookieBannerGroup = 'gdpr-blocker/' + this.config.cookieBannerGroup.trim();
		}

		if (!rendererInstance.previewMode || this.config.previewMode) {
			scriptToLoad = `
				<script 
				   async
					defer 
					type="${cookieBannerGroup}" 
					src="${this.config.dataHost}"
					data-website-id="${this.config.dataWebsiteID}" 
					data-auto-track="${this.config.dataAutoTrack}"
					data-do-not-track="${this.config.doNotTrack}"
					data-cache="${this.config.cache}"
					${dataHostURL}
					${dataDomains}></script>
			`;
		}

		return scriptToLoad;
	}
}

module.exports = UmamiAnalyticsIntegrationPlugin;