class DisqusCommentsPlugin {
	constructor (API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addInsertions () {
		this.API.addInsertion('customCommentsCode', this.addEntryScripts, 1, this);
	}

	addEntryScripts (rendererInstance, context) {
		let url = '';
		let uniquePageID = '';
		let cookieBannerGroup = 'text/javascript';
		let consentScriptToLoad = '';
		let consentNotice = '';
		let cssHeaderClass = ` class="${this.config.cssHeaderClass}"`;
		let cssWrapperClass = ` class="${this.config.cssWrapperClass}"`;
		let cssInnerWrapperClass = ` class="${this.config.cssInnerWrapperClass}"`;

		if (!this.config.cssHeaderClass) {
			cssHeaderClass = '';
		}

		if (!this.config.cssWrapperClass) {
			cssWrapperClass = '';
		}

		if (!this.config.cssInnerWrapperClass) {
			cssInnerWrapperClass = '';
		}

		if (rendererInstance.globalContext && rendererInstance.globalContext.website) {
			url = rendererInstance.globalContext.website.pageUrl;
		}

		if (context) {
			if (context.post && context.post.id) {
				 uniquePageID = context.post.id;
			} else if (context.page && context.page.id) {
				 uniquePageID = context.page.id;
			} else {
				 uniquePageID = url;
			}
	  }	  

		let heading = `
			<h${this.config.headingLevel}${cssHeaderClass}>
		        ${this.config.textHeader}
		    </h${this.config.headingLevel}>
	    `;

	    if (!this.config.textHeader) {
	    	heading = '';
	    }

		let scriptToLoad = `
			(function () {
				var d = document, s = d.createElement('script');
				s.src = 'https://'+('${this.config.shortname}').trim()+'.disqus.com/embed.js';
				s.setAttribute('data-timestamp', +new Date());
				(d.head || d.body).appendChild(s);
			})();
		`;

		if (this.config.lazyload) {
			scriptToLoad = `
				var disqus_element_to_check = document.getElementById('disqus_thread');

				if ('IntersectionObserver' in window) {
					var iObserver = new IntersectionObserver(
						(entries, observer) => {
							entries.forEach(entry => {
								if (entry.intersectionRatio >= 0.1) {
									(function () {
										var d = document, s = d.createElement('script');
										s.src = 'https://'+('${this.config.shortname}').trim()+'.disqus.com/embed.js';
										s.setAttribute('data-timestamp', +new Date());
										(d.head || d.body).appendChild(s);
									})();
									observer.unobserve(entry.target);
								}
							});
						},
						{
							threshold: [0, 0.2, 0.5, 1]
						}
					);

					iObserver.observe(disqus_element_to_check);
				} else {
					(function () {
						var d = document, s = d.createElement('script');
						s.src = 'https://'+('${this.config.shortname}').trim()+'.disqus.com/embed.js';
						s.setAttribute('data-timestamp', +new Date());
						(d.head || d.body).appendChild(s);
					})();
				}
			`;
		}

		if (this.config.cookieBannerIntegration) {
			cookieBannerGroup = 'gdpr-blocker/' + this.config.cookieBannerGroup.trim();
			consentScriptToLoad = `document.body.addEventListener('publii-cookie-banner-unblock-${this.config.cookieBannerGroup.trim()}', function () {
				document.getElementById('disqus-no-consent-info').style.display = 'none';
			}, false);`;
			consentNotice = `<div
				data-gdpr-group="${cookieBannerGroup}"
				id="disqus-no-consent-info" 
				style="background: #f0f0f0; border: 1px solid #ccc; border-radius: 5px; color: #666; display: block; padding: 10px; text-align: center; width: 100%;">
				${this.config.cookieBannerNoConsentText}
			</div>`;
		}

		return `
			<div${cssWrapperClass}>
	            <div${cssInnerWrapperClass}>
	               	${heading}
					
					<div id="disqus_thread"></div>
					<noscript>
						${this.config.textFallback}
					</noscript>
					${consentNotice}
					<script type="${cookieBannerGroup}">
						var disqus_config = function () {
							this.page.url = '${url}';
							this.page.identifier = '${uniquePageID}'; 
							this.language = '${this.config.language}';
						};
						
						${scriptToLoad}
					</script>
					<script type="text/javascript">
						${consentScriptToLoad}
					</script>
				</div>
			</div>
    	`;
	}
}

module.exports = DisqusCommentsPlugin;