class ExternalLinksPlugin {
	constructor(API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addModifiers() {
		const scopes = this.config.scope.split('|');
		const isSiteScope = scopes.includes('site');
		const isPostScope = scopes.includes('post');
		const isPageScope = scopes.includes('page');
		const isBothScope = scopes.includes('both');

		if (isPostScope) {
			this.API.addModifier('postText', this.modifyExternalLinks.bind(this), 1, this);
		}
		if (isPageScope) {
			this.API.addModifier('pageText', this.modifyExternalLinks.bind(this), 1, this);
		}
		if (isBothScope) {
			this.API.addModifier('postText', this.modifyExternalLinks.bind(this), 1, this);
			this.API.addModifier('pageText', this.modifyExternalLinks.bind(this), 1, this);
		}
		if (isSiteScope) {
			this.API.addModifier('htmlOutput', this.modifyExternalLinks.bind(this), 1, this);
		}
	}

	/**
	 * This method modifies external links, adds icons, sets rel, class, and possibly title attributes,
	 * while preserving all other attributes.
	 */
	modifyExternalLinks(rendererInstance, text) {
		const baseUrl = rendererInstance.siteConfig.domain;

		/**
		 * Explanation of this regex:
		 * - We capture all attributes before href as `beforeHrefAttr`
		 * - The protocol (http or https) as `protocol`
		 * - The actual link as `link`
		 * - All attributes after the href="..." as `afterHrefAttr`
		 * - Then the inner HTML as `innerHtml`
		 * 
		 * By capturing `beforeHrefAttr` and `afterHrefAttr`, we can reinsert them 
		 * exactly as they were, minus only the specifically overridden attributes (title, class, rel).
		 */
		const externalLinkRegex = /<\s*a\s+(?<beforeHrefAttr>[^>]*?)href="(?<protocol>https?):\/\/(?<link>[^"]+)"(?<afterHrefAttr>[^>]*)>(?<innerHtml>.*?)<\/a>/gi;

		const iconClass = this.config.iconChoice !== 'no-icon' ? this.config.iconChoice : '';
		const additionalClass = this.config.additionalClass ? ` ${this.config.additionalClass}` : '';
		const linkTitleConfig = this.config.linkTitle; // if set, it overrides the old title
		const overrideRel = this.config.overrideRel;
		const excludeSelectors = this.config.excludeSelectors
			? this.config.excludeSelectors.split('\n').map(sel => sel.trim()).filter(Boolean)
			: [];

		return text.replace(externalLinkRegex, (match, beforeHrefAttr, protocol, link, afterHrefAttr, innerHtml) => {
			// 1. Skip if it's the same domain
			try {
				const linkHostname = new URL(`${protocol}://${link}`).hostname;
				const baseHostname = new URL(baseUrl).hostname;
				if (linkHostname === baseHostname) {
					return match; // not external
				}
			} catch (error) {
				console.error('Invalid URL:', error);
				return match;
			}

			// 2. Excluded selectors: if we detect any excluded class or id, skip
			for (const selector of excludeSelectors) {
				const attributeRegex = new RegExp(`(class|id)="([^"]*\\b${selector}\\b[^"]*)"`);
				if (attributeRegex.test(beforeHrefAttr + afterHrefAttr)) {
					return match; // skip modifying this link
				}
			}

			// Combine all attributes to parse them at once
			let allAttributes = (beforeHrefAttr + afterHrefAttr).trim();

			// Extract original title (if any)
			let oldTitleMatch = allAttributes.match(/\btitle="([^"]*)"/);
			let oldTitle = oldTitleMatch ? oldTitleMatch[1] : '';

			// Extract existing rel (if any)
			let relMatch = allAttributes.match(/\brel="([^"]*)"/);
			let relValues = relMatch ? relMatch[1].split(/\s+/) : [];

			// Extract existing class (if any)
			let classMatch = allAttributes.match(/\bclass="([^"]*)"/);
			let existingClasses = classMatch ? classMatch[1].split(/\s+/) : [];

			/**
			 * 3. Build new or updated attributes
			 */

			// (a) Title
			// If the user set a plugin title, override old title. Otherwise keep the old one.
			let finalTitleValue;
			if (linkTitleConfig && linkTitleConfig.trim()) {
				finalTitleValue = linkTitleConfig;
			} else {
				finalTitleValue = oldTitle; 
			}
			// We'll inject `title="..."` only if there's something to show
			const updatedTitle = finalTitleValue 
				? `title="${finalTitleValue.replace(/"/g, '&quot;')}"` 
				: '';

			// (b) Rel
			const possibleRels = ['nofollow', 'noopener', 'noreferrer', 'sponsored', 'ugc'];
			if (overrideRel) {
				// Remove everything and re-set from config
				relValues = possibleRels.filter(value => {
					const configKey = `add${value.charAt(0).toUpperCase() + value.slice(1)}`;
					return this.config[configKey];
				});
			} else {
				// Append the plugin config rel tokens if not present
				possibleRels.forEach(value => {
					const configKey = `add${value.charAt(0).toUpperCase() + value.slice(1)}`;
					if (this.config[configKey] && !relValues.includes(value)) {
						relValues.push(value);
					}
				});
			}
			const updatedRel = relValues.length > 0 ? `rel="${relValues.join(' ')}"` : '';

			// (c) Class
			// Ensure "extlink" is present
			if (!existingClasses.includes('extlink')) {
				existingClasses.push('extlink');
			}
			// If the user selected an icon class
			if (iconClass && !existingClasses.includes(iconClass)) {
				existingClasses.push(iconClass);
			}
			// Additional user-specified classes
			if (additionalClass.trim()) {
				const addClass = additionalClass.trim();
				if (!existingClasses.includes(addClass)) {
					existingClasses.push(addClass);
				}
			}
			const updatedClass = `class="${existingClasses.join(' ')}"`;

			/**
			 * 4. Remove old rel, class, title from the attribute string only if 
			 *    we are going to re-inject them with updated values.
			 *    We keep all other attributes intact.
			 */
			if (updatedRel) {
				// Remove any old rel=, we'll re-inject
				allAttributes = allAttributes.replace(/\brel="[^"]*"/, '');
			}
			if (classMatch) {
				// We always re-inject class to ensure icon classes are present
				allAttributes = allAttributes.replace(/\bclass="[^"]*"/, '');
			}
			if (updatedTitle) {
				// If we have a finalTitleValue, remove the old so we can re-inject
				allAttributes = allAttributes.replace(/\btitle="[^"]*"/, '');
			}

			/**
			 * 5. If this link wraps any media (img, video, etc.), 
			 *    we do NOT add the icon pseudo-element. 
			 *    That was in the original plugin logic. 
			 */
			const hasMedia = /<img|<video|<iframe|<svg|<object|<embed/i.test(innerHtml);
			if (hasMedia) {
				// If the link wraps media, do not add .extlink or icons
				// But we still keep rel & title adjustments if present
				// (We won't force the extlink class, because original code avoided it.)
				return `<a href="${protocol}://${link}" ${allAttributes} ${updatedTitle} ${updatedRel}>${innerHtml}</a>`;
			} else {
				// For text links, re-inject the updated class
				return `<a href="${protocol}://${link}" ${allAttributes} ${updatedClass} ${updatedTitle} ${updatedRel}>${innerHtml}</a>`;
			}
		});
	}

	addInsertions() {
		const scopes = this.config.scope.split('|');
		const isSiteScope = scopes.includes('site');
		const isPostScope = scopes.includes('post');
		const isPageScope = scopes.includes('page');
		const isBothScope = scopes.includes('both');

		if (isPostScope || isBothScope) {
			this.API.addInsertion('customHeadCode', this.addStyles.bind(this), 1, this);
		}
		if (isPageScope || isBothScope) {
			this.API.addInsertion('customHeadCode', this.addStyles.bind(this), 1, this);
		}
		if (isSiteScope) {
			this.API.addInsertion('customHeadCode', this.addStyles.bind(this), 1, this);
		}
	}

	addStyles(rendererInstance) {
		/**
		 * We only inject icon styles if the current page context matches the plugin scope
		 * and the user has selected an icon.
		 */
		const context = rendererInstance.globalContext.context[0];
		if (
			(this.config.scope === 'post' && context !== 'post') ||
			(this.config.scope === 'page' && context !== 'page') ||
			(this.config.scope === 'both' && context !== 'post' && context !== 'page')
		) {
			return '';
		}

		if (this.config.iconChoice === 'no-icon') {
			return ''; // user doesn't want an icon
		}

		// Prep style variables
		const position = this.config.iconPosition === 'after' ? 'after' : 'before';
		const marginValue = this.config.iconMargin || '5px';
		const iconVerticalPosition = this.config.iconVerticalPosition || '0';
		const iconSize = this.config.iconSize || '16px';
		const iconColor = this.config.iconColorSelect === 'currentColor'
			? 'currentColor'
			: (this.config.iconColor || 'currentColor');

			const iconMap = {
				'extlink-icon-1': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M15 3h6v6\'/><path d=\'M10 14 21 3\'/><path d=\'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6\'/></svg>")',
	
				'extlink-icon-2': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M21 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h6\'/><path d=\'m21 3-9 9\'/><path d=\'M15 3h6v6\'/></svg>")',
	
				'extlink-icon-3': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><rect width=\'18\' height=\'18\' x=\'3\' y=\'3\' rx=\'2\'/><path d=\'M8 8h8v8\'/><path d=\'m8 16 8-8\'/></svg>")',
	
				'extlink-icon-4': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M7 7h10v10\'/><path d=\'M7 17 17 7\'/></svg>")',
	
				'extlink-icon-5': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M22 12A10 10 0 1 1 12 2\'/><path d=\'M22 2 12 12\'/><path d=\'M16 2h6v6\'/></svg>")',
	
				'extlink-icon-6': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path stroke=\'none\' d=\'M0 0h24v24H0z\' fill=\'none\'/><path d=\'M9 12h12\' /><path d=\'M17 16l4 -4l-4 -4\' /><path d=\'M12 3a9 9 0 1 0 0 18\' /></svg>")',
	
				'extlink-icon-7': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path stroke=\'none\' d=\'M0 0h24v24H0z\' fill=\'none\'/><path d=\'M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0\' /><path d=\'M15 9l-6 6\' /><path d=\'M15 15v-6h-6\' /></svg>")',
	
				'extlink-icon-8': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><circle cx=\'11\' cy=\'11\' r=\'8\'/><path d=\'m21 21-4.3-4.3\'/></svg>")',
	
				'extlink-icon-9': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path stroke=\'none\' d=\'M0 0h24v24H0z\'/><path d=\'M13 4v4c-6.575 1.028 -9.02 6.788 -10 12c-.037 .206 5.384 -5.962 10 -6v4l8 -7l-8 -7z\'/></svg>")',
	
				'extlink-icon-10': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path stroke=\'none\' d=\'M0 0h24v24H0z\' fill=\'none\'/><path d=\'M9 15l6 -6\' /><path d=\'M11 6l.463 -.536a5 5 0 0 1 7.071 7.072l-.534 .464\' /><path d=\'M13 18l-.397 .534a5.068 5.068 0 0 1 -7.127 0a4.972 4.972 0 0 1 0 -7.071l.524 -.463\' /></svg>")',
	
				'extlink-icon-11': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71\'/><path d=\'M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71\'/></svg>")',
	
				'extlink-icon-12': 'url("data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23000000\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' xmlns=\'http://www.w3.org/2000/svg\'> <path d=\'M12.298,7.202l-2.672-2.004c-.77-.577-1.842-.525-2.552.126l-4.128,3.784c-.413.379-.649.913-.649,1.473v4.621c0,2.4,2,4,4,4h8.571\' /><path d=\'M14.298,16.202h.571c2.286,0,2.286,3,0,3\' /><path d=\'M14.298,13.202h1.714c2.286,0,2.286,3,0,3h-1.714\' /><path d=\'M14.298,10.202h2.5c2.286,0,2.286,3,0,3h-2.5\' /><path d=\'M14.298,10.202h6.501c.828,0,1.499-.672,1.499-1.5h0c0-.828-.672-1.5-1.5-1.5h-11.5\' /></svg>")',
			};

		let css = `
			.extlink::${position} {
				background-color: ${iconColor};
				content: "";
				display: inline-block;
				height: ${iconSize};
				margin-${position === 'after' ? 'left' : 'right'}: ${marginValue};
				position: relative;
				top: ${iconVerticalPosition}px;
				width: ${iconSize};
			}
		`;

		// Make sure we set mask-image for the chosen icon
		Object.keys(iconMap).forEach(iconKey => {
			if (this.config.iconChoice === iconKey) {
				css += `
					.extlink.${iconKey}::${position} {
						mask-image: ${iconMap[iconKey]};
						mask-repeat: no-repeat;
						mask-size: contain;
					}
				`;
			}
		});

		return `<style>${css}</style>`;
	}
}

module.exports = ExternalLinksPlugin;
