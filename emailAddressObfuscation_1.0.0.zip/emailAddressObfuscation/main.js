class EmailAddressObfuscation {
	constructor(API, name, config) {
		 this.API = API;
		 this.name = name;
		 this.config = config;

		 this.API.addModifier('htmlOutput', this.modifyHTML.bind(this), 1, this);
		 this.API.addInsertion('customFooterCode', this.addScript.bind(this), 1, this);
	}

	// Method Replace: replaces @ with ' AT ' and . with ' DOT ' (with configuration option)
	replaceText(email) {
		 const atReplacement = ` ${this.config.atReplacement || 'AT'} `;
		 const dotReplacement = ` ${this.config.dotReplacement || 'DOT'} `;
		 return email.replace(/@/g, atReplacement).replace(/\./g, dotReplacement);
	}

	// Method Reverse: reverses the user and domain parts
	reverseEmail(email) {
		 const parts = email.split('@');
		 if (parts.length !== 2) return email;
		 const [user, domain] = parts;
		 return {
			  user: user.split('').reverse().join(''),
			  domain: domain.split('').reverse().join('')
		 };
	}

	// Method Rot18
	rot18(email) {
		 const rot18 = (str) => {
			  return str.split('').map(char => {
					const code = char.charCodeAt(0);
					if (code >= 65 && code <= 90) { // A-Z
						 return String.fromCharCode(((code - 65 + 18) % 26) + 65);
					} else if (code >= 97 && code <= 122) { // a-z
						 return String.fromCharCode(((code - 97 + 18) % 26) + 97);
					} else if (code >= 48 && code <= 57) {
						 return String.fromCharCode(((code - 48 + 5) % 10) + 48);
					}
					return char; // Not A-Z, a-z or 0-9? then stay the same
			  }).join('');
		 };

		 const parts = email.split('@');
		 if (parts.length !== 2) return email;

		 return {
			  user: rot18(parts[0]),
			  domain: rot18(parts[1])
		 };
	}

	// Helper function to combine classes
	combineClasses(existingAttributes, newClasses) {
		 const classRegex = /class=(["'])(.*?)\1/i;
		 const match = existingAttributes.match(classRegex);
		 if (match) {
			  const existingClasses = match[2];
			  return `${existingClasses} ${newClasses}`;
		 }
		 return newClasses;
	}

	// Method to obfuscate an email
	obfuscateEmail(email, obfuscationMethod) {
		 switch (obfuscationMethod) {
			  case 'replace':
					return this.replaceText(email);
			  case 'reverse':
					return this.reverseEmail(email);
			  case 'rot18':
					return this.rot18(email);
			  default:
					return this.reverseEmail(email);
		 }
	}
  // Obfuscate plain text email
	 obfuscatePlainEmail(email, obfuscationMethod) {
		 const obfuscated = this.obfuscateEmail(email, obfuscationMethod);
		 if (obfuscationMethod === 'replace') {
			  return `<span class="obfuscated-email">${obfuscated}</span>`;
		 } else {
			  if (typeof obfuscated === 'object' && obfuscated.user && obfuscated.domain) {
					return `<span class="obfuscated-email" data-user="${obfuscated.user}" data-domain="${obfuscated.domain}" data-type="text"></span>`;
			  }
			  return `<span class="obfuscated-email" data-email="${obfuscated}" data-type="text"></span>`;
		 }
	}

	// Obfuscate mailto links while preserving classes
  obfuscateMailtoLink(fullMatch, preAttributes, quote, email, postAttributes, linkText, obfuscationMethod) {
		 const obfuscated = this.obfuscateEmail(email, obfuscationMethod);
		 let classes = this.combineClasses(preAttributes + postAttributes, '');
		 const linkTextTrimmed = linkText.trim();
		 let finalContent = '';
		 // Keep the link text if it's different from the email
		 if (linkTextTrimmed.toLowerCase() !== email.toLowerCase()) {
			  finalContent = linkText;
		 }
		 const isWrapped = /<[a-z]+.*?>.*?<\/[a-z]+>/.test(linkTextTrimmed);
		 if (obfuscationMethod === 'replace') {
			  return `<span class="obfuscated-email${classes ? ' ' + classes : ''}">${finalContent ? finalContent : obfuscated}</span>`;
		 } else {
				if (typeof obfuscated === 'object' && obfuscated.user && obfuscated.domain) {
					return `<span class="obfuscated-email${classes ? ' ' + classes : ''}" data-user="${obfuscated.user}" data-domain="${obfuscated.domain}" data-type="mailto">${isWrapped ? linkText : finalContent}</span>`;
			  } else {
					return `<span class="obfuscated-email${classes ? ' ' + classes : ''}" data-email="${obfuscated}" data-type="mailto">${isWrapped ? linkText : finalContent}</span>`;
			  }
		 }
	}
	// Obfuscate emails in HTML elements (e.g., <strong>, <p>, etc.)
	obfuscateElementEmail(fullMatch, openingTag, tagName, attributes, beforeEmail, email, afterEmail, closingTag, obfuscationMethod) {
		 const obfuscatedEmail = this.obfuscatePlainEmail(email, obfuscationMethod);
		 return `${openingTag}${beforeEmail}${obfuscatedEmail}${afterEmail}${closingTag}`;
	}


	modifyHTML(rendererInstance, htmlCode) {
		 const globalObfuscation = this.config.globalObfuscation;
		 let emailsToObfuscate = [];
		 const obfuscationMethod = this.config.obfuscationMethod || 'reverse';
		 if (this.config.specificEmailsList && this.config.specificEmailsList.trim()) {
			  emailsToObfuscate = this.config.specificEmailsList
					.split(/[\n,]+/)
					.map(email => email.trim())
					.filter(email => email.length > 0);
		 }
		 // Extract head section
		 const headRegex = /(<head[\s\S]*?>)([\s\S]*?)(<\/head>)/i;
		 let headContent = '';
		 if (headRegex.test(htmlCode)) {
			  htmlCode = htmlCode.replace(headRegex, (match, startTag, headInner, endTag) => {
					headContent = startTag + headInner + endTag;
					return '<<<HEAD-PLACEHOLDER>>>';
			  });
		 }

		 // Regular expressions
		 const emailRegex = /[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}/gi;
		 const anchorMailtoRegex = /<a\s+([^>]*?)href=(["'])mailto:([a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,})\2([^>]*)>([\s\S]*?)<\/a>/gi;
		 const elementEmailRegex = /(<([a-z]+)([^>]*?)>)([^<]*?)([a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,})([^<]*?)(<\/\2>)/gi;

		 // Obfuscation Logic
		 if (globalObfuscation) {
			  // Step 1: Obfuscate mailto links
			  htmlCode = htmlCode.replace(anchorMailtoRegex, (fullMatch, preAttributes, quote, email, postAttributes, linkText) =>
					this.obfuscateMailtoLink(fullMatch, preAttributes, quote, email, postAttributes, linkText, obfuscationMethod)
			  );

			  // Step 2: Obfuscate emails in HTML elements
			  htmlCode = htmlCode.replace(elementEmailRegex, (fullMatch, openingTag, tagName, attributes, beforeEmail, email, afterEmail, closingTag) => {
					// Check if element is already obfuscated
					if (/<span[^>]*class="obfuscated-email"[^>]*>/.test(fullMatch)) {
						 return fullMatch;
					}
					return this.obfuscateElementEmail(fullMatch, openingTag, tagName, attributes, beforeEmail, email, afterEmail, closingTag, obfuscationMethod);
			  });

			  // Step 3: Obfuscate plain text emails
			  htmlCode = htmlCode.replace(emailRegex, (match) => {
					// Check if element is already obfuscated
					if (/<span[^>]*class="obfuscated-email"[^>]*>/.test(match)) {
						 return match;
					}
					return this.obfuscatePlainEmail(match, obfuscationMethod);
			  });

		 } else if (emailsToObfuscate.length > 0) {

			  // Obfuscate only emails from the list
			  htmlCode = htmlCode.replace(anchorMailtoRegex, (fullMatch, preAttributes, quote, email, postAttributes, linkText) => {
					if (emailsToObfuscate.some(e => e.toLowerCase() === email.toLowerCase())) {
						 return this.obfuscateMailtoLink(fullMatch, preAttributes, quote, email, postAttributes, linkText, obfuscationMethod);
					}
					return fullMatch;
			  });
			  htmlCode = htmlCode.replace(elementEmailRegex, (fullMatch, openingTag, tagName, attributes, beforeEmail, email, afterEmail, closingTag) => {
					if (emailsToObfuscate.some(e => e.toLowerCase() === email.toLowerCase())) {
						 // Check if element is already obfuscated
						 if (/<span[^>]*class="obfuscated-email"[^>]*>/.test(fullMatch)) {
							  return fullMatch;
						 }
						 return this.obfuscateElementEmail(fullMatch, openingTag, tagName, attributes, beforeEmail, email, afterEmail, closingTag, obfuscationMethod);
					}
					return fullMatch;
			  });
			  emailsToObfuscate.forEach(email => {
					const safeEmail = email.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
					const specificEmailRegex = new RegExp(safeEmail, 'gi');
					htmlCode = htmlCode.replace(specificEmailRegex, (match) => {
						 // Check if element is already obfuscated
						 if (/<span[^>]*class="obfuscated-email"[^>]*>/.test(match)) {
							  return match;
						 }
						 return this.obfuscatePlainEmail(match, obfuscationMethod);
					});
			  });
		 }

		 // Clean emails in head
		 if (headContent) {
			  const emailRegexInHead = /[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}/gi;
			  headContent = headContent.replace(emailRegexInHead, '');
			  htmlCode = htmlCode.replace('<<<HEAD-PLACEHOLDER>>>', headContent);
		 }
		 return htmlCode;
	}


	compressScript(scriptContent) {
		 //Remove comments
		 let compressed = scriptContent.replace(/\/\*[\s\S]*?\*\/|\/\/[\s\S]*?\n/g, '');
		 // Remove multiple spaces, tabs, new lines etc.
		 compressed = compressed.replace(/\s+/g, ' ');
		 // remove trailing white space at begin and the end of string
		 compressed = compressed.trim();
		 return compressed;
	}

  addScript() {
		 const obfuscationMethod = this.config.obfuscationMethod || 'reverse';
		 let scriptContent = '';


		 if (obfuscationMethod === 'reverse') {
			  scriptContent = `
			 <script>
				 'use strict';
				 document.addEventListener('DOMContentLoaded', function() {
					 var obfElements = document.querySelectorAll('.obfuscated-email');
					 obfElements.forEach(function(elem) {
						 var dataType = elem.getAttribute('data-type');
						 var encodedEmail = elem.getAttribute('data-email');
						 var user = elem.getAttribute('data-user');
						 var domain = elem.getAttribute('data-domain');
						 var decodedEmail = '';

								 if (user && domain) {
									 decodedEmail = user.split('').reverse().join('') + '@' + domain.split('').reverse().join('');
								 } else if (encodedEmail) {
									 const parts = encodedEmail.split('@');

									 if (parts.length === 2) {
										 decodedEmail = parts[0].split('').reverse().join('') + '@' + parts[1].split('').reverse().join('');
									 } else {
										 decodedEmail = encodedEmail; // keep
									 }

								 }

						 if (dataType === 'mailto') {

								 var originalText = elem.textContent.trim();
								 var a = document.createElement('a');
								 a.href = 'mailto:' + decodedEmail;

								 if (elem.classList.length > 0) {
									 a.className = elem.className;
								 }
								 if (originalText === '') {
									 a.textContent = decodedEmail;
								 } else {
									 a.textContent = originalText;
								 }
								 elem.parentNode.replaceChild(a, elem);

						 } else if (dataType === 'text') {

								 var textNode = document.createTextNode(decodedEmail);
								 elem.parentNode.replaceChild(textNode, elem);
						 }

					 });
				 });
			 </script>
		 `;
	  } else if (obfuscationMethod === 'rot18') {
			  scriptContent = `
			 <script>
				 class Rot18Encoder {
					 constructor() {
						 this.rotations = [
								 { from: 'a', to: 'z', offset: 18 },
								 { from: 'A', to: 'Z', offset: 18 },
								 { from: '0', to: '9', offset: 5 }
						 ];
					 }

					 _rotate(char, from, to, offset) {
						 const charCode = char.charCodeAt(0);
						 const fromCode = from.charCodeAt(0);
						 const toCode = to.charCodeAt(0);
						 const range = toCode - fromCode + 1;

						 if (charCode >= fromCode && charCode <= toCode) {
								 const shiftedCode = ((charCode - fromCode + offset) % range) + fromCode;
								 return String.fromCharCode(shiftedCode);
						 }
						 return char;
					 }
					 
					 encode(text) {
						 let encodedText = "";
							 for(let char of text){
							 let rotatedChar = char;
							 for (const rot of this.rotations){
								 rotatedChar = this._rotate(rotatedChar, rot.from, rot.to, rot.offset);
							 }
							 encodedText += rotatedChar;
						 }
						 return encodedText;
					 }

					 decode(text) {
						 let decodedText = "";
						 for(let char of text){
							 let rotatedChar = char;
							 for (const rot of this.rotations){
									 rotatedChar = this._rotate(rotatedChar, rot.from, rot.to, rot.to.charCodeAt(0) - rot.from.charCodeAt(0) + 1 - rot.offset);
							 }
							 decodedText += rotatedChar;
							 }
						 return decodedText;
					 }
				 }

				 class TextProcessor {
					 constructor(encoder){
						 this.encoder = encoder;
					 }
					 encode(text){
							 return this.encoder.encode(text);
					 }
					 decode(text){
						 return this.encoder.decode(text);
					 }
				 }


				 document.addEventListener('DOMContentLoaded', function() {
					 const rot18 = new Rot18Encoder();
						 const coder = new TextProcessor(rot18);

						 var obfElements = document.querySelectorAll('.obfuscated-email');
						 obfElements.forEach(function(elem) {
							 var dataType = elem.getAttribute('data-type');
							 var encodedEmail = elem.getAttribute('data-email');
							 var user = elem.getAttribute('data-user');
							 var domain = elem.getAttribute('data-domain');
							 var decodedEmail = '';

									 if (user && domain) {
											 decodedEmail = coder.decode(user) + '@' + coder.decode(domain);
										 } else if (encodedEmail) {
											 const parts = encodedEmail.split('@');
											 if (parts.length === 2) {
												 decodedEmail = coder.decode(parts[0]) + '@' + coder.decode(parts[1]);
											 } else {
												 decodedEmail = encodedEmail;
											 }
										 }
							 if (dataType === 'mailto') {
								 var originalText = elem.textContent.trim();
								 var a = document.createElement('a');
								 a.href = 'mailto:' + decodedEmail;

								 if (elem.classList.length > 0) {
									 a.className = elem.className;
								 }

								 if (originalText === '') {
									 a.textContent = decodedEmail;
								 } else {
									 a.textContent = originalText;
								 }

								 elem.parentNode.replaceChild(a, elem);

							 } else if (dataType === 'text') {
								 var textNode = document.createTextNode(decodedEmail);
								 elem.parentNode.replaceChild(textNode, elem);
							 }
					 });
				 });
		 </script>
		 `;
		 }
		 return this.compressScript(scriptContent);


	}
}

module.exports = EmailAddressObfuscation;