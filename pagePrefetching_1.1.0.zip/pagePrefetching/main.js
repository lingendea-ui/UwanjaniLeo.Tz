class PagePrefetching {
	constructor(API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addInsertions() {
		this.API.addInsertion('publiiFooter', this.addQuicklinkScript, 1, this);
	}

	addQuicklinkScript(rendererInstance) {
		const options = {
			prerender: this.config.prerender,
			el: this.config.el,
			delay: Number(this.config.delay),
			limit: Number(this.config.limit),
			throttle: Number(this.config.throttle),
			timeout: Number(this.config.timeout)
		};

		const elementSelector = options.el ? options.el : 'body';

		let script = `
			<script src="${rendererInstance.siteConfig.domain}/media/plugins/pagePrefetching/quicklink.umd.js"></script>
			<script>
				window.addEventListener('load', () => {
					quicklink.listen({
						prerender: ${options.prerender},
						el: document.querySelector('${elementSelector}'),
						delay: ${options.delay},
						limit: ${options.limit},
						throttle: ${options.throttle},
						timeout: ${options.timeout}
					});
				});
			</script>
		`;
		return script;
	}
}

module.exports = PagePrefetching;
