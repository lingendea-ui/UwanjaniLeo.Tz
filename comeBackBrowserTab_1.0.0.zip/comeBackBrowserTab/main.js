class comeBackBrowserTab {
	constructor(API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addInsertions() {
		this.API.addInsertion('publiiFooter', this.addScript, 1, this);
	}

	addScript() {
		const delay = parseInt(this.config.delay, 10) || 0;
		const returnDelay = parseInt(this.config.returnDelay, 10) || 0;
		const returnTitleDuration = parseInt(this.config.returnTitleDuration, 10) || 2000;
		const awayTitle = JSON.stringify(this.config.awayTitle || 'We miss you!');
		const returnTitle = JSON.stringify(this.config.returnTitle || 'Welcome back!');
	
		return `
	<script>
		(function() {
			var originalTitle = document.title;
			var timeout;
			document.addEventListener("visibilitychange", function() {
				if (document.hidden) {
					${delay > 0
						? `timeout = setTimeout(function() {
							document.title = ${awayTitle};
						}, ${delay});`
						: `document.title = ${awayTitle};`}
				} else {
					clearTimeout(timeout);
					${returnDelay > 0
						? `setTimeout(function() {
							document.title = ${returnTitle};
							setTimeout(function() {
								document.title = originalTitle;
							}, ${returnTitleDuration});
						}, ${returnDelay});`
						: `document.title = ${returnTitle};
							setTimeout(function() {
								document.title = originalTitle;
							}, ${returnTitleDuration});`}
				}
			});
		})();
	</script>`;
	}
	
	
	
}

module.exports = comeBackBrowserTab;
